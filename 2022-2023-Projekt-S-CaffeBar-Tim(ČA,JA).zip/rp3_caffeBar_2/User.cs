﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rp3_caffeBar
{
    internal class User
    {
        public static int userId;
        public static string username;
        public static int isOwner;

    }
}
