﻿namespace rp3_caffeBar
{


    partial class DataSet1
    {
        partial class PRODUCTDataTable
        {
        }

        partial class DataTable1DataTable
        {
        }
    }
}
