﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rp3_caffeBar
{
    internal class ConnectionString
    {

        //MOLIMO PROMIJENITI connectionString S OBZIROM NA ConnectionString naveden u caffeBar.mdf 

        //public static String connectionString =


        public static String connectionString= "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=F:\\Anamaria\\rp3-projekt\\rp3_caffeBar_2\\caffeBar.mdf;Integrated Security=True";
        //public static String connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Dea\\Documents\\GitHub\\rp3-projekt\\rp3_caffeBar_2\\caffeBar.mdf;Integrated Security=True";


    }
}
